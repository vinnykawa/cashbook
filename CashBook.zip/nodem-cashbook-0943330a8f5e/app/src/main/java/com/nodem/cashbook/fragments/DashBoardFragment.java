package com.nodem.cashbook.fragments;

import com.nodem.cashbook.Ledger;
import com.nodem.cashbook.R;
import com.nodem.cashbook.R.layout;
import com.nodem.cashbook.adapters.DashBoardListAdapter;
import com.nodem.cashbook.db.DBReader;
import com.nodem.cashbook.net.SyncToServer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class DashBoardFragment extends Fragment {

	private ListView list_credit,list_debit;
	private TextView credit,debit;
	public static DashBoardFragment newInstance() {
		DashBoardFragment fragment = new DashBoardFragment();

		return fragment;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.dashboard, container, false);

		initViews(rootView);
		refreshList();
		return rootView;
	}

	private void initViews(View vi) {
		 debit = (TextView)vi.findViewById(R.id.txt_debit);
		 credit =(TextView)vi.findViewById(R.id.txt_credit);
		
		list_credit = (ListView)vi.findViewById(R.id.list_credit);
		list_debit = (ListView)vi.findViewById(R.id.list_debit);
		
		
	}
	
	@Override
	public void onResume() {
		refreshList();
		
		super.onResume();
	}

	public void refreshList(){
		DBReader db = new DBReader(getActivity());
		DBReader.TransactionsTable transactions = db.new TransactionsTable();
		final DBReader.TransactionsTable.DashBoard dash = transactions.new DashBoard();
		
		int totalCredit = 0;
		for(int i:dash.getCreditTotals())
			totalCredit+=i;
		
		int totalDebit =0;
		for(int i:dash.getDebitTotals())
			totalDebit +=i;
		
			credit.setText("CREDIT ("+totalCredit+")");
			debit.setText("DEBIT ("+totalDebit+")");
			
			
			DashBoardListAdapter creditAdapter = new DashBoardListAdapter(getActivity(), dash.getCreditors(), dash.getCreditTotals());
			DashBoardListAdapter debitAdapter = new DashBoardListAdapter(getActivity(), dash.getDebtors(), dash.getDebitTotals());
			
		
			list_credit.setAdapter(creditAdapter);
			list_debit.setAdapter(debitAdapter);
			
			list_credit.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					String name =dash.getCreditors().get(position);
					String amnt =dash.getCreditTotals().get(position)+" Cr";
					
					Intent i= new Intent(getActivity(),Ledger.class);
					i.putExtra("name", name);
					i.putExtra("amount", amnt);
					i.putExtra("phone", dash.getContacts(position));
					startActivity(i);
					
				}
			});
			
			list_debit.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					String name =dash.getDebtors().get(position);
					String amnt =dash.getDebitTotals().get(position)+" Dr";
					
					Intent i= new Intent(getActivity(),Ledger.class);
					i.putExtra("name", name);
					i.putExtra("amount", amnt);
					i.putExtra("phone", dash.getContacts(position));
					startActivity(i);
					
				}
			});
		
	}
}